export type Status = 'รอตรวจ' | 'กำลังดำเนินการ' | 'รออนุมัติ' | 'เสร็จแล้ว';
export type Kind = 'ฉลาก' | 'สูตร/ส่วนประกอบ' | 'ทะเบียน อย.' | 'เอกสาร' | 'โรงงาน/มาตรฐาน' | 'อื่น ๆ';
export type Task = {
  id: string;
  title: string;
  kind: Kind;
  productId?: string;
  due: string;
  status: Status;
  note: string;
  createdAt: string;
};
export type Product = {
  id: string;
  sku?: string;
  name: string;
  size: string;
  fdaNumber: string;
  allergens: string[];
  ingredientsNote: string;
  labelStatus: Status;
  ingredients?: { name: string; percent: number; sourceNumber: string }[];
  formulaTotal?: number;
  allergenNote?: string;
  source?: string;
};
export type Material = { id: string; name: string; category: string; usedIn: string; allergen: string; reference: string; storage: string; note: string };
export type RecordItem = {
  id: string;
  title: string;
  category: string;
  reference: string;
  expires: string;
  productId?: string;
  note: string;
};
export type Data = { products: Product[]; materials: Material[]; tasks: Task[]; records: RecordItem[] };
import { sourceMaterials, sourceProducts } from './sourceData';
export const kinds: Kind[] = ['ฉลาก', 'สูตร/ส่วนประกอบ', 'ทะเบียน อย.', 'เอกสาร', 'โรงงาน/มาตรฐาน', 'อื่น ๆ'];
export const statuses: Status[] = ['รอตรวจ', 'กำลังดำเนินการ', 'รออนุมัติ', 'เสร็จแล้ว'];
export const starter: Data = {
  products: sourceProducts,
  materials: sourceMaterials,
  tasks: [
    { id: 't1', title: 'แก้ยอดสูตรพริกผัดน้ำมันงา 103%', kind: 'สูตร/ส่วนประกอบ', productId: 'SO', due: '', status: 'รอตรวจ', note: 'รายชื่อส่วนประกอบน้ำพริก.docx ตารางสูตรพริกผัดน้ำมันงา: ผลรวมรายบรรทัด 103% แต่แถวรวมระบุ 100% ให้ R&D ยืนยันสูตรก่อนใช้ฉลาก', createdAt: '2026-09-27' },
    { id: 't2', title: 'ยืนยันสารก่อภูมิแพ้ซีอิ๊วขาวเห็ดหอม', kind: 'ฉลาก', productId: 'HH', due: '', status: 'รอตรวจ', note: 'FM-RA-07 Rev.01 RM-017 ระบุถั่วเหลือง และให้ขอข้อมูล Supplier เพื่อยืนยันข้าวสาลี/กลูเตน ห้ามระบุว่าไม่มีสารก่อภูมิแพ้', createdAt: '2026-09-27' },
    { id: 't3', title: 'ตรวจความต่าง Flow แมคเคอเรลกับ HACCP CCP-01', kind: 'โรงงาน/มาตรฐาน', productId: 'MC', due: '', status: 'รอตรวจ', note: 'Flow การผลิตน้ำพริกโรงงานคลอง 9.pdf หน้าแมคเคอเรลระบุคลุกเคล้าโดยไม่แสดง ≥85°C/≥120 นาที ขณะที่ QP-HA-001 Rev.00 กำหนด CCP-01 ทุก Batch ให้ QA ยืนยันขั้นตอนและแก้เอกสารให้ตรงกัน', createdAt: '2026-09-27' },
    { id: 't4', title: 'ทวนสถานะน้ำตาลหล่อฮังก๊วย 3 สูตร', kind: 'ทะเบียน อย.', due: '', status: 'รอตรวจ', note: 'FM-RA-07 Rev.01 RM-021 ทำเครื่องหมายประเด็นข้ออนุญาตใน SO, OO-O, OO-S ให้ RA ตรวจข้อกำหนดปัจจุบันและเอกสาร Supplier ก่อนวางขาย', createdAt: '2026-09-27' },
    { id: 't5', title: 'ยืนยันสถานะเกลือเสริมไอโอดีนแยกตามวัตถุดิบ', kind: 'ฉลาก', due: '', status: 'รอตรวจ', note: 'FM-RA-07 Rev.01 RM-005 เกลือหิมาลายัน และ RM-015 เกลือทั่วไป ต้องยืนยันกับ Supplier แยกกันก่อนขึ้นฉลาก', createdAt: '2026-09-27' },
    { id: 't6', title: 'ปิด Critical Readiness และใบอนุญาตโรงงาน', kind: 'โรงงาน/มาตรฐาน', due: '', status: 'กำลังดำเนินการ', note: 'Puisabpak_Master_Factory_Control_V1: PL-001 เปิดค้าง; RD-006 ถึง RD-010 อยู่ In Progress; ตรวจหลักฐานก่อน Trial Run', createdAt: '2026-09-27' }
  ],
  records: [
    { id: 'r1', title: 'HACCP Manual', category: 'คู่มือ', reference: 'QP-HA-001 Rev.00', expires: '', note: 'Effective 21-Sep-2026; CCP-01 และ OPRP-01/02; ตรวจลายเซ็นและฉบับใช้จริง' },
    { id: 'r2', title: 'Raw Material Master Data', category: 'วัตถุดิบ', reference: 'FM-RA-07 Rev.01', expires: '', note: 'สถานะ DRAFT; รวม 23 วัตถุดิบ และ Allergen Matrix 10 SKU' },
    { id: 'r3', title: 'Factory Readiness Control', category: 'โรงงาน', reference: 'V1', expires: '', note: 'มีรายการ Critical และ Punch List ค้าง; สถานะเปลี่ยนได้ ต้องทวนฉบับล่าสุด' }
  ]
};
