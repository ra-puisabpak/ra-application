// Generated from user supplied source files; review source revisions before production use.
import type { Product, Material } from './model';
export const sourceProducts: Product[] = [
  {
    "id": "MC",
    "sku": "MC",
    "name": "น้ำพริกเผ็ดแมคเคอเรล",
    "size": "",
    "fdaNumber": "",
    "allergens": [
      "ปลา"
    ],
    "ingredientsNote": "ปลาแมคเคอเรลเป็นวัตถุดิบหลัก 66%",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "เนื้อปลาแมคเคอเรล",
        "percent": 66.0,
        "sourceNumber": ""
      },
      {
        "name": "หอมแดง",
        "percent": 10.0,
        "sourceNumber": ""
      },
      {
        "name": "พริกแห้ง",
        "percent": 8.0,
        "sourceNumber": ""
      },
      {
        "name": "กระเทียม",
        "percent": 6.0,
        "sourceNumber": ""
      },
      {
        "name": "เกลือหิมาลายัน",
        "percent": 5.0,
        "sourceNumber": "10-1-24961-5-0001"
      },
      {
        "name": "น้ำตาลช่อดอกมะพร้าว",
        "percent": 2.0,
        "sourceNumber": "44-2-00253-6-0002"
      },
      {
        "name": "มะขาม",
        "percent": 2.0,
        "sourceNumber": "11-2-00948-2-0308"
      },
      {
        "name": "น้ำมันรำข้าว",
        "percent": 1.0,
        "sourceNumber": "11-1-22723-6-0001"
      }
    ],
    "formulaTotal": 100.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  },
  {
    "id": "TD",
    "sku": "TD",
    "name": "น้ำพริกตาแดงมันกุ้ง",
    "size": "",
    "fdaNumber": "",
    "allergens": [
      "ปลา",
      "สัตว์น้ำมีเปลือกแข็ง"
    ],
    "ingredientsNote": "มีปลา(น้ำปลา) + สัตว์น้ำมีเปลือกแข็ง(มันกุ้ง+กุ้งแห้ง) รวม 2 แหล่งสัตว์น้ำมีเปลือกแข็ง",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "หอมแดง",
        "percent": 28.0,
        "sourceNumber": ""
      },
      {
        "name": "กระเทียม",
        "percent": 28.0,
        "sourceNumber": ""
      },
      {
        "name": "มันกุ้ง",
        "percent": 12.0,
        "sourceNumber": "74-2-02949-6-0042"
      },
      {
        "name": "พริกแห้ง",
        "percent": 10.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำมันรำข้าว",
        "percent": 6.0,
        "sourceNumber": "11-1-22723-6-0001"
      },
      {
        "name": "น้ำปลา",
        "percent": 5.0,
        "sourceNumber": "20-1-13724-2-0004"
      },
      {
        "name": "มะขาม",
        "percent": 5.0,
        "sourceNumber": "11-2-00948-2-0308"
      },
      {
        "name": "น้ำตาลมะพร้าว",
        "percent": 3.0,
        "sourceNumber": "72-2-00442-6-0006"
      },
      {
        "name": "กุ้งแห้ง",
        "percent": 3.0,
        "sourceNumber": "74-2-02051-2-0023"
      }
    ],
    "formulaTotal": 100.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  },
  {
    "id": "PY",
    "sku": "PY",
    "name": "น้ำพริกปลาย่างพลัส",
    "size": "",
    "fdaNumber": "",
    "allergens": [
      "ปลา"
    ],
    "ingredientsNote": "ปลา 2 แหล่ง (ปลาฉลาดรมควัน+น้ำปลา) — ชนิดปลายังไม่ยืนยัน",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "หอมแดง",
        "percent": 26.0,
        "sourceNumber": ""
      },
      {
        "name": "กระเทียม",
        "percent": 22.0,
        "sourceNumber": ""
      },
      {
        "name": "ปลาฉลาดรมควัน",
        "percent": 16.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำปลา",
        "percent": 12.0,
        "sourceNumber": "20-1-13724-2-0004"
      },
      {
        "name": "พริกแห้ง",
        "percent": 12.0,
        "sourceNumber": ""
      },
      {
        "name": "มะขาม",
        "percent": 6.0,
        "sourceNumber": "11-2-00948-2-0308"
      },
      {
        "name": "น้ำมันรำข้าว",
        "percent": 3.0,
        "sourceNumber": "11-1-22723-6-0001"
      },
      {
        "name": "น้ำตาลมะพร้าว",
        "percent": 3.0,
        "sourceNumber": "72-2-00442-6-0006"
      }
    ],
    "formulaTotal": 100.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  },
  {
    "id": "PR",
    "sku": "PR",
    "name": "น้ำพริกปลาร้าพริกสด",
    "size": "",
    "fdaNumber": "",
    "allergens": [
      "ปลา"
    ],
    "ingredientsNote": "ปลา 2 แหล่ง (ปลาร้า+น้ำปลา)",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "ปลาร้าปลากระดี่ต้มสุก",
        "percent": 29.0,
        "sourceNumber": ""
      },
      {
        "name": "กระเทียม",
        "percent": 24.0,
        "sourceNumber": ""
      },
      {
        "name": "หอมแดง",
        "percent": 22.0,
        "sourceNumber": ""
      },
      {
        "name": "พริกสด",
        "percent": 15.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำปลา",
        "percent": 7.0,
        "sourceNumber": "20-1-13724-2-0004"
      },
      {
        "name": "เกลือ",
        "percent": 3.0,
        "sourceNumber": "76-2-01062-6-0002"
      }
    ],
    "formulaTotal": 100.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  },
  {
    "id": "HH",
    "sku": "HH",
    "name": "น้ำพริกเห็ดหอมมังสวิรัติ",
    "size": "",
    "fdaNumber": "",
    "allergens": [
      "ถั่วเหลือง"
    ],
    "ingredientsNote": "⚠️ เปลี่ยนจากเดิม — เพิ่มซีอิ้วขาวเห็ดหอม ทำให้ไม่ใช่ SKU ปลอดสารก่อภูมิแพ้อีกต่อไป ต้องตรวจสอบข้าวสาลี/กลูเตนเพิ่ม",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "เห็ดหอม",
        "percent": 57.0,
        "sourceNumber": "11-2-00948-2-0293"
      },
      {
        "name": "หอมแดง",
        "percent": 10.0,
        "sourceNumber": ""
      },
      {
        "name": "กระเทียม",
        "percent": 10.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำตาลมะพร้าวแท้",
        "percent": 8.0,
        "sourceNumber": "72-2-00442-6-0006"
      },
      {
        "name": "ซีอิ้วขาวเห็ดหอม",
        "percent": 6.0,
        "sourceNumber": "11-1-10528-2-0078"
      },
      {
        "name": "เกลือหิมาลายัน",
        "percent": 4.0,
        "sourceNumber": "10-1-24961-5-0001"
      },
      {
        "name": "พริกแห้ง",
        "percent": 3.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำมันรำข้าว",
        "percent": 2.0,
        "sourceNumber": "11-1-22723-6-0001"
      }
    ],
    "formulaTotal": 100.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  },
  {
    "id": "NPW",
    "sku": "NPW",
    "name": "น้ำปลาหวานแซ่บ",
    "size": "",
    "fdaNumber": "",
    "allergens": [
      "ปลา",
      "สัตว์น้ำมีเปลือกแข็ง"
    ],
    "ingredientsNote": "มีทั้งน้ำปลาแท้และกุ้งแห้ง",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "น้ำตาลมะพร้าว",
        "percent": 45.0,
        "sourceNumber": "72-2-00442-6-0006"
      },
      {
        "name": "กุ้งแห้ง",
        "percent": 19.0,
        "sourceNumber": "74-2-02051-2-0028"
      },
      {
        "name": "พริก",
        "percent": 14.0,
        "sourceNumber": ""
      },
      {
        "name": "หอมแดง",
        "percent": 16.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำปลาแท้",
        "percent": 6.0,
        "sourceNumber": "20-1-13724-2-0004"
      }
    ],
    "formulaTotal": 100.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  },
  {
    "id": "SO",
    "sku": "SO",
    "name": "พริกผัดน้ำมันงา · PSP89",
    "size": "",
    "fdaNumber": "",
    "allergens": [
      "งา"
    ],
    "ingredientsNote": "น้ำมันงา+งาขาวคั่ว 2 แหล่ง — สารก่อภูมิแพ้งาทั้งสูตร",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "หอมแดง",
        "percent": 59.0,
        "sourceNumber": ""
      },
      {
        "name": "กระเทียม",
        "percent": 22.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำมันงา",
        "percent": 15.0,
        "sourceNumber": "73-1-28931-2-0002"
      },
      {
        "name": "งาขาวคั่ว",
        "percent": 2.0,
        "sourceNumber": "11-2-03868-6-0054"
      },
      {
        "name": "น้ำมันหอมเจียว (รำข้าว)",
        "percent": 2.0,
        "sourceNumber": "11-1-22723-6-0001"
      },
      {
        "name": "พริกแห้ง",
        "percent": 1.0,
        "sourceNumber": ""
      },
      {
        "name": "เกลือหิมาลายัน",
        "percent": 1.0,
        "sourceNumber": "10-1-24961-5-0001"
      },
      {
        "name": "น้ำตาลหล่อฮังก๊วย",
        "percent": 1.0,
        "sourceNumber": "10-3-08350-5-0003"
      }
    ],
    "formulaTotal": 103.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  },
  {
    "id": "OO-S",
    "sku": "OO-S",
    "name": "พริกผัดน้ำมันมะกอก (เผ็ด) · PSP05",
    "size": "",
    "fdaNumber": "",
    "allergens": [],
    "ingredientsNote": "⭐ ไม่มีสารก่อภูมิแพ้หลักที่ระบุ",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "หอมแดง",
        "percent": 53.0,
        "sourceNumber": ""
      },
      {
        "name": "กระเทียม",
        "percent": 19.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำมันมะกอก Extra Light",
        "percent": 14.0,
        "sourceNumber": "10-3-10542-1-2512"
      },
      {
        "name": "พริกแห้ง",
        "percent": 9.0,
        "sourceNumber": ""
      },
      {
        "name": "เกลือหิมาลายัน",
        "percent": 2.0,
        "sourceNumber": "10-1-24961-5-0001"
      },
      {
        "name": "น้ำมันรำข้าว",
        "percent": 2.0,
        "sourceNumber": "11-1-22723-6-0001"
      },
      {
        "name": "น้ำตาลหล่อฮังก๊วย",
        "percent": 1.0,
        "sourceNumber": "10-3-08350-5-0003"
      }
    ],
    "formulaTotal": 100.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  },
  {
    "id": "OO-O",
    "sku": "OO-O",
    "name": "พริกผัดน้ำมันมะกอก (ออริจินอล) · PSP17",
    "size": "",
    "fdaNumber": "",
    "allergens": [],
    "ingredientsNote": "⭐ ไม่มีสารก่อภูมิแพ้หลักที่ระบุ",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "หอมแดง",
        "percent": 59.0,
        "sourceNumber": ""
      },
      {
        "name": "กระเทียม",
        "percent": 21.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำมันมะกอก Extra Light",
        "percent": 14.0,
        "sourceNumber": "10-3-10542-1-2512"
      },
      {
        "name": "พริกแห้ง",
        "percent": 2.0,
        "sourceNumber": ""
      },
      {
        "name": "น้ำมันรำข้าว",
        "percent": 2.0,
        "sourceNumber": "11-1-22723-6-0001"
      },
      {
        "name": "เกลือหิมาลายัน",
        "percent": 1.0,
        "sourceNumber": "10-1-24961-5-0001"
      },
      {
        "name": "น้ำตาลหล่อฮังก๊วย",
        "percent": 1.0,
        "sourceNumber": "10-3-08350-5-0003"
      }
    ],
    "formulaTotal": 100.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  },
  {
    "id": "CP",
    "sku": "CP",
    "name": "พริกคั่วป่น (วัตถุดิบกึ่งสำเร็จรูป)",
    "size": "",
    "fdaNumber": "",
    "allergens": [],
    "ingredientsNote": "⭐ พริกป่นล้วน 100% ไม่มีสารก่อภูมิแพ้",
    "labelStatus": "รอตรวจ",
    "ingredients": [
      {
        "name": "พริกป่น",
        "percent": 100.0,
        "sourceNumber": ""
      }
    ],
    "formulaTotal": 100.0,
    "source": "FM-RA-07 Rev.01 (DRAFT); รายชื่อส่วนประกอบน้ำพริก.docx"
  }
];
export const sourceMaterials: Material[] = [
  {
    "id": "RM-001",
    "name": "เนื้อปลาแมคเคอเรล",
    "category": "สัตว์น้ำ",
    "usedIn": "MC",
    "allergen": "ปลา (Fish)",
    "reference": "ยังไม่มีเลข อย.",
    "storage": "แช่เย็น/แช่แข็ง",
    "note": "วัตถุดิบหลัก 66% ของสูตร MC — ขอ COA+ใบรับรองแหล่งจับ/เพาะเลี้ยง"
  },
  {
    "id": "RM-002",
    "name": "หอมแดง",
    "category": "ผัก",
    "usedIn": "MC, TD, PY, PR, HH, NPW",
    "allergen": "ไม่มี",
    "reference": "-",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": "ใช้ใน 6/10 สูตร"
  },
  {
    "id": "RM-003",
    "name": "พริกแห้ง",
    "category": "เครื่องเทศ",
    "usedIn": "MC, TD, PY, HH",
    "allergen": "ไม่มี",
    "reference": "-",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": ""
  },
  {
    "id": "RM-004",
    "name": "กระเทียม",
    "category": "ผัก",
    "usedIn": "แทบทุกสูตร (8/10)",
    "allergen": "ไม่มี",
    "reference": "-",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": "ใช้มากที่สุดในบรรดาวัตถุดิบทั้งหมด"
  },
  {
    "id": "RM-005",
    "name": "เกลือหิมาลายัน",
    "category": "เครื่องปรุงรส",
    "usedIn": "MC, HH, พริกผัดน้ำมันงา, พริกผัดน้ำมันมะกอก x2",
    "allergen": "ไม่มี",
    "reference": "10-1-24961-5-0001",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": "ต้องยืนยันสถานะเสริมไอโอดีนกับ Supplier ก่อนขึ้นฉลาก (ตามหลักเกณฑ์เกลือบริโภค)"
  },
  {
    "id": "RM-006",
    "name": "น้ำตาลช่อดอกมะพร้าว / น้ำตาลมะพร้าว(แท้)",
    "category": "เครื่องปรุงรส",
    "usedIn": "MC, TD, PY, HH",
    "allergen": "ไม่มี*",
    "reference": "44-2-00253-6-0002 (MC) / 72-2-00442-6-0006 (TD,PY,HH)",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": "⚠️ ชื่อคล้ายกันแต่เลข อย. ต่างกัน 2 ชุด — ยืนยันว่าเป็นคนละล็อต/ซัพพลายเออร์หรือพิมพ์ผิด | *มะพร้าวไม่จัดเป็น Tree Nut ตาม Codex/ไทย แต่บางประเทศจัดเป็น Tree Nut"
  },
  {
    "id": "RM-007",
    "name": "มะขาม / มะขามเปียก",
    "category": "ผลไม้/เครื่องปรุง",
    "usedIn": "MC, TD, PY",
    "allergen": "ไม่มี",
    "reference": "11-2-00948-2-0308",
    "storage": "อุณหภูมิห้อง",
    "note": ""
  },
  {
    "id": "RM-008",
    "name": "น้ำมันรำข้าว / น้ำมันหอมเจียว(รำข้าว)",
    "category": "น้ำมัน",
    "usedIn": "MC, TD, PY, HH, พริกผัดน้ำมันงา",
    "allergen": "ไม่มี",
    "reference": "11-1-22723-6-0001",
    "storage": "อุณหภูมิห้อง",
    "note": ""
  },
  {
    "id": "RM-009",
    "name": "มันกุ้ง",
    "category": "สัตว์น้ำ",
    "usedIn": "TD",
    "allergen": "สัตว์น้ำมีเปลือกแข็ง (Crustacean)",
    "reference": "74-2-02949-6-0042",
    "storage": "แช่เย็น/แช่แข็ง",
    "note": "สารก่อภูมิแพ้สำคัญ — ต้องระบุบนฉลาก"
  },
  {
    "id": "RM-010",
    "name": "น้ำปลา / น้ำปลาแท้",
    "category": "เครื่องปรุงรส",
    "usedIn": "TD, PY, PR, NPW",
    "allergen": "ปลา (Fish)",
    "reference": "20-1-13724-2-0004",
    "storage": "อุณหภูมิห้อง",
    "note": "ใช้ใน 4/10 สูตร — สารก่อภูมิแพ้สำคัญ"
  },
  {
    "id": "RM-011",
    "name": "กุ้งแห้ง",
    "category": "สัตว์น้ำ",
    "usedIn": "TD, NPW",
    "allergen": "สัตว์น้ำมีเปลือกแข็ง (Crustacean)",
    "reference": "74-2-02051-2-0023 (TD) / 74-2-02051-2-0028 (NPW)",
    "storage": "แช่เย็น/แห้ง",
    "note": "⚠️ เลข อย. ต่างกันระหว่าง 2 สูตร — ยืนยันกับฝ่ายจัดซื้อว่าคนละซัพพลายเออร์/ล็อตจริงหรือพิมพ์ผิด"
  },
  {
    "id": "RM-012",
    "name": "ปลาฉลาดรมควัน",
    "category": "สัตว์น้ำ",
    "usedIn": "PY",
    "allergen": "ปลา (Fish)",
    "reference": "ยังไม่มีเลข อย.",
    "storage": "แช่เย็น/แช่แข็ง",
    "note": "ต้องยืนยันชนิดปลาและชื่อที่ถูกต้องกับ R&D — ชื่ออาจคลาดเคลื่อนจากการพิมพ์/OCR"
  },
  {
    "id": "RM-013",
    "name": "ปลาร้าปลากระดี่ต้มสุก",
    "category": "เครื่องปรุงรส/สัตว์น้ำหมัก",
    "usedIn": "PR",
    "allergen": "ปลา (Fish)",
    "reference": "ยังไม่มีเลข อย.",
    "storage": "อุณหภูมิห้อง/แช่เย็น",
    "note": "วัตถุดิบหลัก 29% ของสูตร PR"
  },
  {
    "id": "RM-014",
    "name": "พริกสด",
    "category": "เครื่องเทศ/ผัก",
    "usedIn": "PR",
    "allergen": "ไม่มี",
    "reference": "-",
    "storage": "แช่เย็น",
    "note": ""
  },
  {
    "id": "RM-015",
    "name": "เกลือ",
    "category": "เครื่องปรุงรส",
    "usedIn": "PR",
    "allergen": "ไม่มี",
    "reference": "76-2-01062-6-0002",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": "คนละรายการกับเกลือหิมาลายัน (RM-005) — ต้องยืนยันสถานะไอโอดีนแยกกัน"
  },
  {
    "id": "RM-016",
    "name": "เห็ดหอม",
    "category": "เห็ด",
    "usedIn": "HH",
    "allergen": "ไม่มี",
    "reference": "11-2-00948-2-0293",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": "วัตถุดิบหลัก 57% ของสูตร HH"
  },
  {
    "id": "RM-017",
    "name": "ซีอิ้วขาวเห็ดหอม",
    "category": "เครื่องปรุงรส",
    "usedIn": "HH",
    "allergen": "ถั่วเหลือง (Soy) — ตรวจสอบข้าวสาลี/กลูเตนเพิ่ม",
    "reference": "11-1-10528-2-0078",
    "storage": "อุณหภูมิห้อง",
    "note": "⚠️ สารก่อภูมิแพ้ใหม่ที่เพิ่งเข้ามาในสูตร HH — เดิมเข้าใจว่า HH ไม่มีสารก่อภูมิแพ้เลย ต้องขอ COA/สูตรจาก Supplier ยืนยันว่ามีข้าวสาลีเป็นส่วนประกอบหรือไม่"
  },
  {
    "id": "RM-018",
    "name": "พริก (ยังไม่ระบุชนิด)",
    "category": "เครื่องเทศ",
    "usedIn": "NPW",
    "allergen": "ไม่มี",
    "reference": "-",
    "storage": "รอข้อมูล",
    "note": "ต้องยืนยันว่าเป็นพริกสดหรือพริกแห้งกับ R&D"
  },
  {
    "id": "RM-019",
    "name": "น้ำมันงา",
    "category": "น้ำมัน",
    "usedIn": "พริกผัดน้ำมันงา",
    "allergen": "งา (Sesame)",
    "reference": "73-1-28931-2-0002",
    "storage": "อุณหภูมิห้อง",
    "note": "สารก่อภูมิแพ้ใหม่ — ไม่เคยมีในสูตรเดิม 6 SKU"
  },
  {
    "id": "RM-020",
    "name": "งาขาวคั่ว",
    "category": "เครื่องเทศ",
    "usedIn": "พริกผัดน้ำมันงา",
    "allergen": "งา (Sesame)",
    "reference": "11-2-03868-6-0054",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": "สารก่อภูมิแพ้ใหม่"
  },
  {
    "id": "RM-021",
    "name": "น้ำตาลหล่อฮังก๊วย",
    "category": "สารให้ความหวาน",
    "usedIn": "พริกผัดน้ำมันงา, พริกผัดน้ำมันมะกอก x2",
    "allergen": "ไม่มี",
    "reference": "10-3-08350-5-0003",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": "🚩 ยังไม่ใช่สารเติมแต่งที่ได้รับอนุมัติสำหรับหมวดนี้ตาม อย. — ต้องยื่นประเมินสารเติมแต่งหรือเปลี่ยนสูตรก่อนวางขาย (พบใน 3 สูตรใหม่)"
  },
  {
    "id": "RM-022",
    "name": "น้ำมันมะกอก Extra Light",
    "category": "น้ำมัน",
    "usedIn": "พริกผัดน้ำมันมะกอก x2",
    "allergen": "ไม่มี",
    "reference": "10-3-10542-1-2512",
    "storage": "อุณหภูมิห้อง",
    "note": "🚩 ต้องตรวจสอบว่าเกรด/ชื่อตรงกับประกาศฯ 421 บัญชีหมายเลข 1 ก่อนขึ้นฉลาก"
  },
  {
    "id": "RM-023",
    "name": "พริกป่น",
    "category": "เครื่องเทศ / วัตถุดิบกึ่งสำเร็จรูป",
    "usedIn": "พริกคั่วป่น (CP, 100%)",
    "allergen": "ไม่มี",
    "reference": "-",
    "storage": "อุณหภูมิห้อง แห้ง",
    "note": "เป็นวัตถุดิบกึ่งสำเร็จรูป — ตรวจสอบว่าใช้เป็น Input ของสูตรอื่นด้วยหรือไม่"
  }
];
